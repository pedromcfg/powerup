import { Button } from "@/components/ui/button";
import { TrendingUp } from "lucide-react";
import { HeroGeometric } from "@/components/ui/shape-landing-hero";

export const Hero = () => {
  return (
    <HeroGeometric
      badge=""
      title1="Treinos de registro"
      title2="Fique mais forte"
      description="Torne os seus treinos simples e eficazes. Acompanhe o progresso, alcance objetivos e mantenha-se motivado com a Power Up."
      buttons={
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            variant="default" 
            size="lg" 
            className="group bg-primary hover:bg-primary/90"
            onClick={() => window.location.href = '/install'}
          >
            Instalar Aplicação
            <TrendingUp className="ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
          <Button 
            variant="outline" 
            size="lg"
            className="border-white/20 text-white hover:bg-white/10"
            onClick={() => window.location.href = '/app'}
          >
            Saber Mais
          </Button>
        </div>
      }
    />
  );
};
