import { Button } from "@/components/ui/button";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Download, Smartphone, CheckCircle } from "lucide-react";
import powerUpLogo from "@/assets/power-up-logo.png";

const Install = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-16">
        <section className="py-24 bg-gradient-subtle">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center animate-fade-in">
              <div className="flex justify-center mb-8">
                <img src={powerUpLogo} alt="Power Up" className="h-20" />
              </div>

              <h1 className="text-4xl lg:text-6xl font-bold mb-6">
                Instala a
                <span className="bg-gradient-hero bg-clip-text text-transparent">
                  {" "}
                  Power Up
                </span>
              </h1>

              <p className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto">
                Leva o teu treino para o próximo nível. Descarrega a nossa aplicação e treina onde quiseres, quando quiseres.
              </p>

              <div className="grid md:grid-cols-2 gap-8 mb-12">
                <div className="bg-card rounded-3xl p-8 shadow-medium border border-border/50 text-left">
                  <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.48-3.24 0-1.44.62-2.2.44-3.06-.4C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09l.01-.01zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
                    </svg>
                  </div>
                  <h3 className="text-2xl font-bold mb-3">iOS</h3>
                  <p className="text-muted-foreground mb-6">
                    Disponível na App Store para iPhone e iPad
                  </p>
                  <Button variant="default" size="lg" className="w-full">
                    <Download className="mr-2" />
                    Descarregar para iOS
                  </Button>
                </div>

                <div className="bg-card rounded-3xl p-8 shadow-medium border border-border/50 text-left">
                  <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M3,20.5V3.5C3,2.91 3.34,2.39 3.84,2.15L13.69,12L3.84,21.85C3.34,21.6 3,21.09 3,20.5M16.81,15.12L6.05,21.34L14.54,12.85L16.81,15.12M20.16,10.81C20.5,11.08 20.75,11.5 20.75,12C20.75,12.5 20.5,12.92 20.16,13.19L17.89,14.5L15.39,12L17.89,9.5L20.16,10.81M6.05,2.66L16.81,8.88L14.54,11.15L6.05,2.66Z"/>
                    </svg>
                  </div>
                  <h3 className="text-2xl font-bold mb-3">Android</h3>
                  <p className="text-muted-foreground mb-6">
                    Disponível na Google Play Store
                  </p>
                  <Button variant="default" size="lg" className="w-full">
                    <Download className="mr-2" />
                    Descarregar para Android
                  </Button>
                </div>
              </div>

              <div className="bg-card rounded-3xl p-8 shadow-medium border border-border/50">
                <h2 className="text-2xl font-bold mb-6">
                  Porquê usar a aplicação?
                </h2>
                <div className="grid md:grid-cols-3 gap-6">
                  <div>
                    <CheckCircle className="w-8 h-8 text-primary mb-3 mx-auto" />
                    <h3 className="font-semibold mb-2">Offline</h3>
                    <p className="text-sm text-muted-foreground">
                      Acede aos teus treinos mesmo sem internet
                    </p>
                  </div>
                  <div>
                    <Smartphone className="w-8 h-8 text-primary mb-3 mx-auto" />
                    <h3 className="font-semibold mb-2">Notificações</h3>
                    <p className="text-sm text-muted-foreground">
                      Recebe lembretes para não falhar treinos
                    </p>
                  </div>
                  <div>
                    <CheckCircle className="w-8 h-8 text-primary mb-3 mx-auto" />
                    <h3 className="font-semibold mb-2">Rápido</h3>
                    <p className="text-sm text-muted-foreground">
                      Experiência otimizada para mobile
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Install;
