import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, Crown, Zap, Star } from "lucide-react";

const PowerUpPro = () => {
  const freeFeatures = [
    "Treinos ilimitados",
    "Registo de exercícios",
    "Acompanhamento básico de progresso",
    "Calendário de treinos",
  ];

  const proFeatures = [
    "Tudo do plano gratuito",
    "Treinos personalizados com IA",
    "Estatísticas avançadas e relatórios",
    "Planos de treino profissionais",
    "Aconselhamento nutricional",
    "Suporte prioritário",
    "Sem anúncios",
    "Modo offline completo",
    "Exportação de dados",
  ];

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-16">
        {/* Hero Section */}
        <section className="relative py-20 lg:py-32 bg-gradient-subtle">
          <div className="absolute top-20 left-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl"></div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl mx-auto text-center animate-fade-in">
              <div className="inline-flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full mb-6">
                <Crown className="w-5 h-5 text-primary" />
                <span className="text-sm font-semibold text-primary">Premium</span>
              </div>
              <h1 className="text-4xl lg:text-6xl font-bold mb-6">
                Power Up
                <span className="bg-gradient-hero bg-clip-text text-transparent"> Pro</span>
              </h1>
              <p className="text-lg text-muted-foreground mb-8">
                Leva os teus treinos ao próximo nível com funcionalidades premium, 
                treinos personalizados com IA e acompanhamento profissional.
              </p>
            </div>
          </div>
        </section>

        {/* Pricing Cards */}
        <section className="py-20 lg:py-32">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
              {/* Free Plan */}
              <Card className="border-border/50">
                <CardHeader className="text-center pb-8">
                  <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                    <Zap className="w-6 h-6 text-foreground" />
                  </div>
                  <CardTitle className="text-2xl mb-2">Gratuito</CardTitle>
                  <CardDescription className="text-base">
                    Perfeito para começar
                  </CardDescription>
                  <div className="mt-4">
                    <span className="text-4xl font-bold">0€</span>
                    <span className="text-muted-foreground">/mês</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-8">
                    {freeFeatures.map((feature, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                        <span className="text-muted-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button variant="outline" className="w-full" onClick={() => window.location.href = '/auth'}>
                    Começar Grátis
                  </Button>
                </CardContent>
              </Card>

              {/* Pro Plan */}
              <Card className="border-primary/50 relative overflow-hidden shadow-medium">
                <div className="absolute top-0 right-0 bg-primary text-primary-foreground px-4 py-1 text-sm font-semibold">
                  Recomendado
                </div>
                <CardHeader className="text-center pb-8">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Crown className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-2xl mb-2">Pro</CardTitle>
                  <CardDescription className="text-base">
                    Para atletas dedicados
                  </CardDescription>
                  <div className="mt-4">
                    <span className="text-4xl font-bold">9.99€</span>
                    <span className="text-muted-foreground">/mês</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-8">
                    {proFeatures.map((feature, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button variant="hero" className="w-full" onClick={() => window.location.href = '/auth'}>
                    Começar Teste Grátis
                  </Button>
                  <p className="text-sm text-muted-foreground text-center mt-4">
                    14 dias grátis • Cancela quando quiseres
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-20 bg-gradient-subtle">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-16">
                <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                  Porque Escolher o Pro?
                </h2>
                <p className="text-lg text-muted-foreground">
                  Investe no teu fitness e obtém resultados mais rápidos
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Star className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">IA Personalizada</h3>
                  <p className="text-muted-foreground">
                    Treinos criados especificamente para ti, adaptados aos teus objetivos
                  </p>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Zap className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Resultados Rápidos</h3>
                  <p className="text-muted-foreground">
                    Planos otimizados para maximizar os teus resultados em menos tempo
                  </p>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Crown className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Suporte Premium</h3>
                  <p className="text-muted-foreground">
                    Acesso prioritário ao suporte e aconselhamento profissional
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default PowerUpPro;
