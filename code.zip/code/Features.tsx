import { Card } from "@/components/ui/card";
import { BarChart3, Calendar, Trophy, Users, Zap, Shield } from "lucide-react";

const features = [
  {
    icon: BarChart3,
    title: "Acompanhar Progresso",
    description: "Monitoriza o teu desempenho com análises detalhadas e gráficos de progresso visuais.",
  },
  {
    icon: Calendar,
    title: "Planear Treinos",
    description: "Cria planos de treino personalizados e agenda-os para se adaptarem perfeitamente à tua rotina.",
  },
  {
    icon: Trophy,
    title: "Definir Objetivos",
    description: "Define os teus objetivos fitness e acompanha marcos à medida que os alcanças.",
  },
  {
    icon: Users,
    title: "Comunidade",
    description: "Conecta-te com outros entusiastas do fitness e partilha as tuas conquistas.",
  },
];

export const Features = () => {
  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl lg:text-5xl font-bold mb-4">
            Tudo o Que Precisas de
            <span className="bg-gradient-hero bg-clip-text text-transparent"> Saber Sobre:</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Funcionalidades poderosas desenvolvidas para tornar a tua jornada fitness simples, eficaz e agradável.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="p-8 hover:shadow-medium transition-all duration-300 hover:-translate-y-1 border-border/50 animate-fade-in-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="w-12 h-12 rounded-lg bg-gradient-hero flex items-center justify-center mb-4">
                <feature.icon className="w-6 h-6 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
