import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dumbbell, Trophy, TrendingUp, Calendar, BarChart3, Zap } from "lucide-react";

const AppPage = () => {
  const features = [
    {
      icon: Dumbbell,
      title: "Treinos Personalizados",
      description: "Cria e personaliza os teus treinos de acordo com os teus objetivos. Escolhe exercícios, séries, repetições e tempo de descanso."
    },
    {
      icon: Calendar,
      title: "Planeamento Semanal",
      description: "Organiza a tua semana de treinos com facilidade. Visualiza e ajusta o teu calendário de treinos a qualquer momento."
    },
    {
      icon: BarChart3,
      title: "Acompanhamento de Progresso",
      description: "Regista todos os teus treinos e acompanha a tua evolução ao longo do tempo com gráficos detalhados."
    },
    {
      icon: Trophy,
      title: "Objetivos e Conquistas",
      description: "Define metas realistas e celebra cada conquista. Mantém-te motivado com o sistema de conquistas."
    },
    {
      icon: TrendingUp,
      title: "Estatísticas Detalhadas",
      description: "Acede a estatísticas completas sobre os teus treinos, volume de treino, e progressão em cada exercício."
    },
    {
      icon: Zap,
      title: "Treinos Offline",
      description: "Usa a aplicação em qualquer lugar, mesmo sem ligação à internet. Os teus dados sincronizam automaticamente."
    }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-16">
        {/* Hero Section */}
        <section className="relative py-20 lg:py-32 bg-gradient-subtle">
          <div className="absolute top-20 right-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl"></div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl mx-auto text-center animate-fade-in">
              <h1 className="text-4xl lg:text-6xl font-bold mb-6">
                A Tua App de
                <span className="bg-gradient-hero bg-clip-text text-transparent"> Fitness Completa</span>
              </h1>
              <p className="text-lg text-muted-foreground mb-8">
                Power Up é a aplicação perfeita para quem quer levar os seus treinos para o próximo nível. 
                Regista, acompanha e alcança os teus objetivos fitness de forma simples e intuitiva.
              </p>
              <Button variant="hero" size="lg" onClick={() => window.location.href = '/install'}>
                Instalar Aplicação
              </Button>
            </div>
          </div>
        </section>

        {/* Features Grid */}
        <section className="py-20 lg:py-32">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                Funcionalidades Principais
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Tudo o que precisas para gerir os teus treinos e alcançar os teus objetivos
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <Card key={index} className="border-border/50 hover:shadow-medium transition-all duration-300">
                    <CardHeader>
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                        <Icon className="w-6 h-6 text-primary" />
                      </div>
                      <CardTitle className="text-xl">{feature.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-base">
                        {feature.description}
                      </CardDescription>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-subtle">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <div className="bg-card rounded-3xl p-12 lg:p-16 shadow-medium border border-border/50">
                <h2 className="text-3xl lg:text-4xl font-bold mb-6">
                  Pronto Para Começar?
                </h2>
                <p className="text-lg text-muted-foreground mb-8">
                  Instala a aplicação agora e começa a tua jornada fitness hoje mesmo.
                </p>
                <Button variant="hero" size="lg" onClick={() => window.location.href = '/install'}>
                  Instalar Power Up
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default AppPage;
