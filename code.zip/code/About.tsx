import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, Target, Users, Zap, Instagram, Linkedin } from "lucide-react";
import { TeamSection } from "@/components/ui/team-section";

const About = () => {
  const values = [
    {
      icon: Heart,
      title: "Paixão pelo Ginásio",
      description: "Acreditamos que o treino deve ser acessível a todos, independentemente do nível de experiência."
    },
    {
      icon: Target,
      title: "Foco em Resultados",
      description: "A nossa missão é ajudar-te a alcançar os teus objetivos com ferramentas simples e eficazes."
    },
    {
      icon: Users,
      title: "Comunidade",
      description: "Construímos uma comunidade de apoio onde todos se motivam mutuamente."
    },
    {
      icon: Zap,
      title: "Ser Saudável",
      description: "Promovemos hábitos saudáveis que melhoram a qualidade de vida de forma sustentável."
    }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-16">
        {/* Hero Section */}
        <section className="relative py-20 lg:py-32 bg-gradient-subtle">
          <div className="absolute bottom-20 right-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl"></div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl mx-auto text-center animate-fade-in">
              <h1 className="text-4xl lg:text-6xl font-bold mb-6">
                Sobre
                <span className="bg-gradient-hero bg-clip-text text-transparent"> Nós</span>
              </h1>
              <p className="text-lg text-muted-foreground mb-8">
                A história de como nasceu a Power Up e a nossa missão de transformar os dias e os treinos melhores.
              </p>
            </div>
          </div>
        </section>

        {/* Story Section */}
        <section className="py-20 lg:py-32">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="mb-16">
                <h2 className="text-3xl lg:text-4xl font-bold mb-6">
                  Como Tudo Começou
                </h2>
                <div className="space-y-6 text-lg text-muted-foreground">
                  <p>
                    Somos quatro amigos apaixonados por ginásio e bem-estar, que acreditam que o treino deve ser para todos, independentemente das suas capacidades físicas. Foi assim que nasceu a nossa ideia: criar uma aplicação de treinos inclusiva, que não só ajuda quem frequenta o ginásio, mas também oferece soluções adaptadas para pessoas com deficiência.
                  </p>
                  <p>
                    Queremos que cada pessoa se sinta motivada, segura e apoiada no seu caminho para uma vida mais saudável. Acreditamos que o exercício é uma ferramenta poderosa para melhorar a qualidade de vida, e a nossa missão é tornar esse caminho acessível e personalizado para todos.
                  </p>
                  <p>
                    Esta aplicação é o reflexo da nossa amizade, dos nossos valores e do desejo de fazer a diferença, unindo tecnologia, treino e inclusão num só lugar.
                  </p>
                </div>
              </div>

              {/* Values */}
              <div>
                <h2 className="text-3xl lg:text-4xl font-bold mb-12 text-center">
                  Os Nossos Valores
                </h2>
                <div className="grid md:grid-cols-2 gap-8">
                  {values.map((value, index) => {
                    const Icon = value.icon;
                    return (
                      <Card key={index} className="border-border/50">
                        <CardContent className="pt-6">
                          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                            <Icon className="w-6 h-6 text-primary" />
                          </div>
                          <h3 className="text-xl font-bold mb-2">{value.title}</h3>
                          <p className="text-muted-foreground">{value.description}</p>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <TeamSection
          title="NOSSA EQUIPA"
          description="Com dedicação e paixão pelo que fazemos, formamos uma equipa dedicada a criar uma aplicação de treinos que realmente transforma vidas. Cada membro traz competências únicas e um compromisso forte com a inclusão."
          members={[
            {
              name: "Miguel",
              designation: "Co-Fundador & Developer",
              imageSrc: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1974&auto=format&fit=crop",
              socialLinks: [
                { icon: Linkedin, href: "#" },
                { icon: Instagram, href: "#" },
              ],
            },
            {
              name: "Sofia",
              designation: "Co-Fundadora & Designer",
              imageSrc: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1974&auto=format&fit=crop",
              socialLinks: [
                { icon: Linkedin, href: "#" },
                { icon: Instagram, href: "#" },
              ],
            },
            {
              name: "André",
              designation: "Co-Fundador & Marketing",
              imageSrc: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=1974&auto=format&fit=crop",
              socialLinks: [
                { icon: Linkedin, href: "#" },
                { icon: Instagram, href: "#" },
              ],
            },
            {
              name: "Carolina",
              designation: "Co-Fundadora & Fitness Expert",
              imageSrc: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=1974&auto=format&fit=crop",
              socialLinks: [
                { icon: Linkedin, href: "#" },
                { icon: Instagram, href: "#" },
              ],
            },
          ]}
          socialLinksMain={[
            { icon: Instagram, href: "#" },
            { icon: Linkedin, href: "#" },
          ]}
        />
      </main>
      <Footer />
    </div>
  );
};

export default About;
